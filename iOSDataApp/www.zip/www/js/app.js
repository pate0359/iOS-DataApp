//app.js

//var app= {
//	loadRequirements:0,
//	init: function(){
//		document.addEventListener("deviceready", app.onDeviceReady);
//		document.addEventListener("DOMContentLoaded", app.onDomReady);
//	},
//	onDeviceReady: function(){
//		app.loadRequirements++;
//		if(app.loadRequirements === 2){
//			app.start();
//		}
//	},
//	onDomReady: function(){
//		app.loadRequirements++;
//		if(app.loadRequirements === 2){
//			app.start();
//		}
//	},
//	start: function(){
//		//connect to database
//		//build the lists for the main pages based on data
//		//add button and navigation listeners
//	}
//}
//
//app.init();


var app = angular.module('myApp', ['ngAnimate','ngTouch']);

app.controller('myCtrl', function($scope){
	
	$scope.myValue=false;
	
//	$scope.name="test";
//	$scope.emails=[{from:"ada@gmail.com",body:"hello Hows are you?",showActions:"true"},{from:"ada@gmail.com",body:"asdfd asfas asfas",showActions:"true"}];
	
//	$scope.counter = 0;
//	$scope.add = function(i){
//		$scope.counter += i;
//	};
//	$scope.substrack = function(i){
//		$scope.counter -= 1;
//	};	
	
//	$scope.direction = 'left';
//	
//	$scope.prevSlide = function () {
//            $scope.direction = 'left';
////            $scope.currentIndex = ($scope.currentIndex < $scope.slides.length - 1) ? ++$scope.currentIndex : 0;
//        };
//
//        $scope.nextSlide = function () {
//            $scope.direction = 'right';
////            $scope.currentIndex = ($scope.currentIndex > 0) ? --$scope.currentIndex : $scope.slides.length - 1;
//        };
	
}); /* .animation('.slide-animation', function () {
        return {
            beforeAddClass: function (element, className, done) {
                var scope = element.scope();

                if (className == 'ng-hide') {
                    var finishPoint = element.parent().width();
                    if(scope.direction !== 'right') {
                        finishPoint = -finishPoint;
                    }
                    TweenMax.to(element, 0.5, {left: finishPoint, onComplete: done });
                }
                else {
                    done();
                }
            },
            removeClass: function (element, className, done) {
                var scope = element.scope();

                if (className == 'ng-hide') {
                    element.removeClass('ng-hide');

                    var startPoint = element.parent().width();
                    if(scope.direction === 'right') {
                        startPoint = -startPoint;
                    }

                    TweenMax.fromTo(element, 0.5, { left: startPoint }, {left: 0, onComplete: done });
                }
                else {
                    done();
                }
            }
        };
    }); */

//var app = angular.module('myApp', []);
//app.controller('myCtrl', function($scope) {
//    $scope.name= "John";
////    $scope.lastName= "Doe";
//});